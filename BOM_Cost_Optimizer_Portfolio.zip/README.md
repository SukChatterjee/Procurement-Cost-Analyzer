# BOM Cost Optimizer (Excel + Python + SQL)

A small procurement/operations analytics toolkit to estimate build cost, compare vendors, and validate pricing data.
Built to mimic how teams do quick sourcing decisions: **spreadsheet-first**, then **Python/SQL checks**.

## Key features
- **Vendor price catalog**: multiple vendor price lists per part (Vendor_A / Vendor_B / Vendor_C)
- **BOM costing**: total quantity + extended cost + grand total for a build run
- **Vendor comparison**: switch vendors and instantly see total cost change
- **Data quality checks** (Python/SQL):
  - missing price detection
  - duplicate part ID checks
- **What-if ready**: change build quantity and see cost impact

## Project structure
- `excel/` → pricing catalog + BOM cost model (`BOM_Cost_Optimizer.xlsx`)
- `python/` → export summaries + run validation checks (`bom_costing.py`)
- `sql/` → schema + analytics queries (`schema.sql`, `example_queries.sql`)
- `screenshots/` → quick visuals of the workbook tabs

## Quick start
### Excel
1. Open `excel/BOM_Cost_Optimizer.xlsx`
2. Update **Build_Qty** (cell **B4**)
3. Choose **Vendor** per part in the BOM table
4. Review unit prices, total cost, and grand total

### Python
```bash
python python/bom_costing.py --xlsx excel/BOM_Cost_Optimizer.xlsx --out output
```

### SQL (optional)
Run `sql/schema.sql` to create tables, then use `sql/example_queries.sql` for:
- line-level costing
- vendor rollups
- missing price checks

## Notes
All data is synthetic and for demonstration only.
