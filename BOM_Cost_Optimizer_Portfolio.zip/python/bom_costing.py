"""BOM Cost Optimizer (Excel -> CSV summaries)

Usage:
  python bom_costing.py --xlsx ../excel/BOM_Cost_Optimizer.xlsx --out ../output

What it does:
- Reads vendor price lists from Vendor_A / Vendor_B / Vendor_C tabs
- Reads the Product_BOM tab (BOM lines + Build_Qty)
- Pulls the correct unit price for each BOM line based on chosen vendor + Part_ID
- Computes Total_Qty and Total_Cost
- Exports:
    - bom_cost_summary.csv (line-level)
    - vendor_cost_breakdown.csv (rollup by vendor)
    - dq_issues.csv (missing prices, duplicates)
"""

import argparse
from pathlib import Path

import pandas as pd


def read_vendor_prices(xlsx: Path, sheet: str) -> pd.DataFrame:
    df = pd.read_excel(xlsx, sheet_name=sheet, header=2)  # headers at row 3 in Excel
    df = df.rename(columns={"Part_ID": "part_id", "Part_Name": "part_name", "Unit_Price": "unit_price"})
    df = df[["part_id", "part_name", "unit_price"]].dropna(subset=["part_id"])
    df["vendor"] = sheet
    return df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xlsx", type=Path, required=True)
    ap.add_argument("--out", type=Path, default=Path("output"))
    args = ap.parse_args()

    xlsx = args.xlsx
    out = args.out
    out.mkdir(parents=True, exist_ok=True)

    vendors = pd.concat(
        [read_vendor_prices(xlsx, s) for s in ["Vendor_A", "Vendor_B", "Vendor_C"]],
        ignore_index=True,
    )

    bom = pd.read_excel(xlsx, sheet_name="Product_BOM", header=6)  # headers at row 7
    bom = bom.rename(
        columns={
            "Part_ID": "part_id",
            "Part_Name": "part_name",
            "Vendor": "vendor",
            "Qty_Per_Product": "qty_per_product",
        }
    )
    bom = bom[["part_id", "part_name", "vendor", "qty_per_product"]].dropna(subset=["part_id"])

    # Read Build_Qty from cell B4
    build_qty = pd.read_excel(xlsx, sheet_name="Product_BOM", header=None).iloc[3, 1]
    build_qty = int(build_qty)

    # Lookup unit price by (vendor, part_id)
    price_map = vendors.set_index(["vendor", "part_id"])["unit_price"]
    bom["unit_price"] = bom.apply(lambda r: price_map.get((r["vendor"], r["part_id"])), axis=1)

    bom["total_qty"] = bom["qty_per_product"] * build_qty
    bom["total_cost"] = bom["total_qty"] * bom["unit_price"]

    bom.to_csv(out / "bom_cost_summary.csv", index=False)

    vendor_rollup = (
        bom.groupby("vendor", as_index=False)["total_cost"]
        .sum()
        .sort_values("total_cost", ascending=False)
    )
    vendor_rollup.to_csv(out / "vendor_cost_breakdown.csv", index=False)

    # Data quality checks
    dq = []
    missing_price = bom[bom["unit_price"].isna()][["part_id", "part_name", "vendor"]]
    if not missing_price.empty:
        missing_price = missing_price.assign(issue="Missing unit price")
        dq.append(missing_price)

    dup_parts = vendors[vendors.duplicated(subset=["vendor", "part_id"], keep=False)][
        ["vendor", "part_id", "part_name"]
    ]
    if not dup_parts.empty:
        dup_parts = dup_parts.assign(issue="Duplicate part_id in vendor sheet")
        dq.append(dup_parts.rename(columns={"vendor": "vendor", "part_id": "part_id", "part_name": "part_name"}))

    if dq:
        dq_df = pd.concat(dq, ignore_index=True)
    else:
        dq_df = pd.DataFrame(columns=["part_id", "part_name", "vendor", "issue"])

    dq_df.to_csv(out / "dq_issues.csv", index=False)

    grand_total = float(bom["total_cost"].sum())
    print(f"Build_Qty={build_qty} | Grand_Total=${grand_total:,.2f}")
    print(f"Wrote outputs to: {out.resolve()}")


if __name__ == "__main__":
    main()
