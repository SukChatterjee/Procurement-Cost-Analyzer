-- Example queries: cost rollups + validation checks

DECLARE @ProductCode VARCHAR(30) = 'DEMO_WIDGET_V2';
DECLARE @BuildQty INT = 25;

-- 1) Line-level cost for a build run
SELECT
    b.Product_Code,
    v.Vendor_Name,
    p.Part_ID,
    p.Part_Name,
    b.Qty_Per_Product,
    (@BuildQty * b.Qty_Per_Product) AS Total_Qty,
    vp.Unit_Price,
    (@BuildQty * b.Qty_Per_Product * vp.Unit_Price) AS Total_Cost
FROM dbo.BOM b
JOIN dbo.Vendor v       ON v.Vendor_ID = b.Vendor_ID
JOIN dbo.Part p         ON p.Part_ID   = b.Part_ID
JOIN dbo.Vendor_Price vp ON vp.Vendor_ID = b.Vendor_ID AND vp.Part_ID = b.Part_ID
WHERE b.Product_Code = @ProductCode
ORDER BY Total_Cost DESC;

-- 2) Rollup: total cost by vendor
SELECT
    v.Vendor_Name,
    SUM(@BuildQty * b.Qty_Per_Product * vp.Unit_Price) AS Vendor_Total_Cost
FROM dbo.BOM b
JOIN dbo.Vendor v       ON v.Vendor_ID = b.Vendor_ID
JOIN dbo.Vendor_Price vp ON vp.Vendor_ID = b.Vendor_ID AND vp.Part_ID = b.Part_ID
WHERE b.Product_Code = @ProductCode
GROUP BY v.Vendor_Name
ORDER BY Vendor_Total_Cost DESC;

-- 3) Data quality: BOM parts that have no price for the chosen vendor
SELECT
    b.Product_Code,
    v.Vendor_Name,
    b.Part_ID
FROM dbo.BOM b
JOIN dbo.Vendor v ON v.Vendor_ID = b.Vendor_ID
LEFT JOIN dbo.Vendor_Price vp ON vp.Vendor_ID = b.Vendor_ID AND vp.Part_ID = b.Part_ID
WHERE b.Product_Code = @ProductCode
  AND vp.Unit_Price IS NULL;

-- 4) Data quality: duplicate Part_IDs (should return 0 rows because of PK)
-- SELECT Vendor_ID, Part_ID, COUNT(*) FROM dbo.Vendor_Price GROUP BY Vendor_ID, Part_ID HAVING COUNT(*) > 1;
