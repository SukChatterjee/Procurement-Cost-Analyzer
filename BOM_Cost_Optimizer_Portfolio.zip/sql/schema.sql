-- BOM Cost Optimizer schema (SQL Server compatible)

CREATE TABLE dbo.Vendor (
    Vendor_ID   INT IDENTITY(1,1) PRIMARY KEY,
    Vendor_Name VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE dbo.Part (
    Part_ID     VARCHAR(20) NOT NULL PRIMARY KEY,
    Part_Name   VARCHAR(100) NOT NULL
);

CREATE TABLE dbo.Vendor_Price (
    Vendor_ID   INT NOT NULL,
    Part_ID     VARCHAR(20) NOT NULL,
    Unit_Price  DECIMAL(12,2) NOT NULL,
    CONSTRAINT PK_Vendor_Price PRIMARY KEY (Vendor_ID, Part_ID),
    CONSTRAINT FK_VP_Vendor FOREIGN KEY (Vendor_ID) REFERENCES dbo.Vendor(Vendor_ID),
    CONSTRAINT FK_VP_Part   FOREIGN KEY (Part_ID) REFERENCES dbo.Part(Part_ID)
);

CREATE TABLE dbo.BOM (
    Product_Code     VARCHAR(30) NOT NULL,
    Part_ID          VARCHAR(20) NOT NULL,
    Vendor_ID        INT NOT NULL,
    Qty_Per_Product  INT NOT NULL,
    CONSTRAINT PK_BOM PRIMARY KEY (Product_Code, Part_ID),
    CONSTRAINT FK_BOM_Part   FOREIGN KEY (Part_ID) REFERENCES dbo.Part(Part_ID),
    CONSTRAINT FK_BOM_Vendor FOREIGN KEY (Vendor_ID) REFERENCES dbo.Vendor(Vendor_ID)
);
